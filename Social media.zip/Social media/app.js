let currentUser = null;
let authToken = null;

document.addEventListener('DOMContentLoaded', () => {
  // Check if user is already logged in
  const token = localStorage.getItem('token');
  if (token) {
    authToken = token;
    fetchCurrentUser();
  }

  // Event listeners
  document.getElementById('login-form').addEventListener('submit', handleLogin);
  document.getElementById('register-form').addEventListener('submit', handleRegister);
  document.getElementById('logout-btn').addEventListener('click', handleLogout);
  document.getElementById('update-bio-btn').addEventListener('click', updateBio);
  document.getElementById('post-submit').addEventListener('click', createPost);
});

async function fetchCurrentUser() {
  try {
    const response = await fetch('/api/users/me', {
      headers: {
        'Authorization': authToken
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch user');
    }
    
    const data = await response.json();
    currentUser = data.user;
    showMainApp();
    loadPosts();
    loadProfile();
  } catch (error) {
    console.error('Error:', error);
    localStorage.removeItem('token');
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || 'Login failed');
    }

    authToken = data.token;
    localStorage.setItem('token', authToken);
    currentUser = data.user;
    showMainApp();
    loadPosts();
    loadProfile();
  } catch (error) {
    alert(error.message);
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const username = document.getElementById('register-username').value;
  const password = document.getElementById('register-password').value;

  try {
    const response = await fetch('/api/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || 'Registration failed');
    }

    authToken = data.token;
    localStorage.setItem('token', authToken);
    currentUser = { username };
    showMainApp();
    loadPosts();
    loadProfile();
  } catch (error) {
    alert(error.message);
  }
}

function handleLogout() {
  localStorage.removeItem('token');
  authToken = null;
  currentUser = null;
  document.getElementById('auth-container').classList.remove('hidden');
  document.getElementById('main-container').classList.add('hidden');
}

function showMainApp() {
  document.getElementById('auth-container').classList.add('hidden');
  document.getElementById('main-container').classList.remove('hidden');
  document.getElementById('username-display').textContent = currentUser.username;
}

async function loadProfile() {
  try {
    const response = await fetch(`/api/users/${currentUser.id}`, {
      headers: {
        'Authorization': authToken
      }
    });
    
    const data = await response.json();
    if (!response.ok) {
      throw new Error('Failed to load profile');
    }
    
    const profileInfo = document.getElementById('profile-info');
    profileInfo.innerHTML = `
      <p><strong>Username:</strong> ${data.user.username}</p>
      <p><strong>Bio:</strong> ${data.user.bio || 'No bio yet'}</p>
      <p><strong>Followers:</strong> ${data.user.followers.length}</p>
      <p><strong>Following:</strong> ${data.user.following.length}</p>
    `;
    
    document.getElementById('bio-input').value = data.user.bio || '';
  } catch (error) {
    console.error('Error:', error);
  }
}

async function updateBio() {
  const bio = document.getElementById('bio-input').value;
  
  try {
    const response = await fetch(`/api/users/${currentUser.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authToken
      },
      body: JSON.stringify({ bio })
    });
    
    if (!response.ok) {
      throw new Error('Failed to update bio');
    }
    
    loadProfile();
  } catch (error) {
    console.error('Error:', error);
  }
}

async function loadPosts() {
  try {
    const response = await fetch('/api/posts', {
      headers: {
        'Authorization': authToken
      }
    });
    
    const data = await response.json();
    if (!response.ok) {
      throw new Error('Failed to load posts');
    }
    
    renderPosts(data);
  } catch (error) {
    console.error('Error:', error);
  }
}

function renderPosts(posts) {
  const postsContainer = document.getElementById('posts-container');
  postsContainer.innerHTML = '';
  
  posts.forEach(post => {
    const postElement = document.createElement('div');
    postElement.className = 'post';
    postElement.dataset.postId = post._id;
    
    const isLiked = post.likes.includes(currentUser.id);
    
    postElement.innerHTML = `
      <div class="post-header">
        <span class="post-user">${post.user.username}</span>
        <span class="post-time">${new Date(post.createdAt).toLocaleString()}</span>
      </div>
      <div class="post-content">${post.content}</div>
      <div class="post-actions">
        <button class="like-btn ${isLiked ? 'liked' : ''}" data-post-id="${post._id}">
          Like (${post.likes.length})
        </button>
        <button class="comment-btn" data-post-id="${post._id}">
          Comment (${post.comments.length})
        </button>
      </div>
      <div class="comments-section" id="comments-${post._id}" style="display: none;">
        ${post.comments.map(comment => `
          <div class="comment">
            <span class="comment-user">${comment.user.username}:</span>
            <span>${comment.content}</span>
          </div>
        `).join('')}
        <div class="comment-form">
          <input type="text" class="comment-input" placeholder="Add a comment...">
          <button class="comment-submit" data-post-id="${post._id}">Post</button>
        </div>
      </div>
    `;
    
    postsContainer.appendChild(postElement);
  });
  
  // Add event listeners for like and comment buttons
  document.querySelectorAll('.like-btn').forEach(btn => {
    btn.addEventListener('click', handleLike);
  });
  
  document.querySelectorAll('.comment-btn').forEach(btn => {
    btn.addEventListener('click', toggleComments);
  });
  
  document.querySelectorAll('.comment-submit').forEach(btn => {
    btn.addEventListener('click', addComment);
  });
}

async function handleLike(e) {
  const postId = e.target.dataset.postId;
  
  try {
    const response = await fetch(`/api/posts/${postId}/like`, {
      method: 'POST',
      headers: {
        'Authorization': authToken
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to like post');
    }
    
    loadPosts();
  } catch (error) {
    console.error('Error:', error);
  }
}

function toggleComments(e) {
  const postId = e.target.dataset.postId;
  const commentsSection = document.getElementById(`comments-${postId}`);
  commentsSection.style.display = commentsSection.style.display === 'none' ? 'block' : 'none';
}

async function addComment(e) {
  const postId = e.target.dataset.postId;
  const commentInput = e.target.previousElementSibling;
  const content = commentInput.value;
  
  if (!content.trim()) return;
  
  try {
    const response = await fetch(`/api/posts/${postId}/comments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authToken
      },
      body: JSON.stringify({ content })
    });
    
    if (!response.ok) {
      throw new Error('Failed to add comment');
    }
    
    commentInput.value = '';
    loadPosts();
  } catch (error) {
    console.error('Error:', error);
  }
}

async function createPost() {
  const content = document.getElementById('post-content').value;
  
  if (!content.trim()) return;
  
  try {
    const response = await fetch('/api/posts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authToken
      },
      body: JSON.stringify({ content })
    });
    
    if (!response.ok) {
      throw new Error('Failed to create post');
    }
    
    document.getElementById('post-content').value = '';
    loadPosts();
  } catch (error) {
    console.error('Error:', error);
  }
}